.\objects\control.o: user\control.c
.\objects\control.o: user\control.h
.\objects\control.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\control.o: user\manual.h
.\objects\control.o: user\auto.h
.\objects\control.o: user\pwm_output.h
.\objects\control.o: user\rc_input.h
