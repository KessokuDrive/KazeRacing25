.\objects\manual.o: user\manual.c
.\objects\manual.o: user\manual.h
.\objects\manual.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\manual.o: user\rc_input.h
.\objects\manual.o: user\pwm_output.h
