.\objects\fpu.o: ..\lib\driverlib\fpu.c
.\objects\fpu.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\fpu.o: ..\lib\inc/hw_nvic.h
.\objects\fpu.o: ..\lib\inc/hw_types.h
.\objects\fpu.o: ..\lib\driverlib/fpu.h
