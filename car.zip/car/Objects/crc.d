.\objects\crc.o: ..\lib\driverlib\crc.c
.\objects\crc.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdbool.h
.\objects\crc.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\crc.o: ..\lib\inc/hw_ccm.h
.\objects\crc.o: ..\lib\inc/hw_memmap.h
.\objects\crc.o: ..\lib\inc/hw_types.h
.\objects\crc.o: ..\lib\driverlib/crc.h
.\objects\crc.o: ..\lib\driverlib/debug.h
