.\objects\auto.o: user\auto.c
.\objects\auto.o: user\auto.h
.\objects\auto.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\auto.o: user\data.h
.\objects\auto.o: user\pwm_output.h
