.\objects\sw_crc.o: ..\lib\driverlib\sw_crc.c
.\objects\sw_crc.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\sw_crc.o: ..\lib\driverlib/sw_crc.h
