.\objects\data.o: user\data.c
.\objects\data.o: user\data.h
.\objects\data.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
