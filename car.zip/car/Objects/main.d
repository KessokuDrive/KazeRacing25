.\objects\main.o: user\main.c
.\objects\main.o: D:\MCU\app\arm\Keil_v5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\main.o: ..\lib\inc\tm4c123gh6pm.h
.\objects\main.o: user\rc_input.h
.\objects\main.o: user\pwm_output.h
.\objects\main.o: user\manual.h
.\objects\main.o: user\auto.h
.\objects\main.o: user\control.h
